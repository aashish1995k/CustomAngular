import { Component, OnInit } from '@angular/core';

import { AuthenticationService } from '@app/_services';

@Component({
  selector: 'layout-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  curerentDate: Date;
  logonTime: string;
  cssID: string;
  dvop: any;
  accounts: string;
  amtPromised: string;
  headerData: any = {};
  curerentDateString: string;
  constructor(private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.headerData = this.authenticationService.currentUserValue.header;  
    this.curerentDate = new Date();
    this.logonTime = `${this.curerentDate.getHours()}:${this.curerentDate.getMinutes()}:${this.curerentDate.getSeconds()} `;   
  }

}
