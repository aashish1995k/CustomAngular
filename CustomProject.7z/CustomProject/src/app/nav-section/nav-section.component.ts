import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '@app/_services';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'layout-nav',
  templateUrl: './nav-section.component.html',
  styleUrls: ['./nav-section.component.css']
})
export class NavSectionComponent implements OnInit {
  customersData: any;
  currentSelectedCustomer: any;
  defaultCustomer: string = 'Primary Customer';
  customerDataForm: FormGroup;
  showMMN: boolean = false;
  constructor(private formBuilder: FormBuilder, private authenticationService: AuthenticationService) { }

  ngOnInit() {
    this.customersData = this.authenticationService.currentUserValue.customersData;
    this.initializeSelection(this.defaultCustomer);
    this.initializeData();
  }

  initializeData() {   
    this.customerDataForm = this.formBuilder.group({
      customerType: [this.currentSelectedCustomer[0].customerType, Validators.required],
      account: [this.currentSelectedCustomer[0].acct, Validators.required],
      ssn: [this.currentSelectedCustomer[0].ssn],
      mmn: [this.currentSelectedCustomer[0].mmn],
      line1: [this.currentSelectedCustomer[0].address.line1],
      line2: [`${this.currentSelectedCustomer[0].address.state}, ${this.currentSelectedCustomer[0].address.postalCode}`],
      email: [this.currentSelectedCustomer[0].email],
      h: [this.currentSelectedCustomer[0].h],
      w: [this.currentSelectedCustomer[0].w],
      ao: [this.currentSelectedCustomer[0].ao]
  });
  }

  initializeSelection(customerType:string) {
    this.currentSelectedCustomer = this.customersData.filter(customer => {
      return customer.customerType === customerType;
    })
  }

  onCustomerChange(customer:any) {   
    this.initializeSelection(customer.customerType);
    this.initializeData();
  }

  _showMMN() {
    this.showMMN = !this.showMMN;
  }
}
